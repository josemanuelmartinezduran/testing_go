TODO
====

  - Document IgnoreCase and IgnoreUnknownKeys in README.
