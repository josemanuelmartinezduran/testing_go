package cmd

// Version defines the current Pop version.
const Version = "v4.13.1"
