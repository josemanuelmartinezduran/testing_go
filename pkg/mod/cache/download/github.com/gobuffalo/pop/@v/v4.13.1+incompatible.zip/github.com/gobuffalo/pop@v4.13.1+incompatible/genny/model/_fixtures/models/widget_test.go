package models

import "testing"

func (ms *ModelSuite) Test_Widget() {
	ms.Fail("This test needs to be implemented!")
}
