package cmd

// Version defines the current Pop version.
// this version will also be used by soda(also buffalo-pop)
const Version = "v6.1.1"
