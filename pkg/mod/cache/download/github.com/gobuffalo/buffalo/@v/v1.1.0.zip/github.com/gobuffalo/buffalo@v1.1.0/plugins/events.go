package plugins

const (
	EvtSetupStarted  = "buffalo-plugins:setup:started"
	EvtSetupErr      = "buffalo-plugins:setup:err"
	EvtSetupFinished = "buffalo-plugins:setup:finished"
)
