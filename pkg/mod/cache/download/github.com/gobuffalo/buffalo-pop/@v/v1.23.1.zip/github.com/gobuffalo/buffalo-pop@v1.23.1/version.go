package main

// Version of main
const Version = "v1.23.1"
