package errx

// Version of errx
const Version = "v1.1.0"
