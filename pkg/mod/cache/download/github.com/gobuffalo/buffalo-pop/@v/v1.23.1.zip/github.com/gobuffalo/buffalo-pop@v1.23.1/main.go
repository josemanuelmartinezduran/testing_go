package main

import "github.com/gobuffalo/buffalo-pop/cmd"

//go:generate packr2

func main() {
	cmd.Execute()
}
