package pop

// Version is the current pop version (not the buffalo-pop one).
const Version = "v4.12.2"
