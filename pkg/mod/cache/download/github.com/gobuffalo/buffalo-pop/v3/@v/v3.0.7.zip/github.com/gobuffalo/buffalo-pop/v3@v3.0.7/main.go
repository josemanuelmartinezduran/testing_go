package main

import "github.com/gobuffalo/buffalo-pop/v3/cmd"

func main() {
	cmd.Execute()
}
