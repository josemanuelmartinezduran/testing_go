package destroy

var YesToAll bool
