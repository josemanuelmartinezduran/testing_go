# github.com/gobuffalo/refresh Stands on the Shoulders of Giants

github.com/gobuffalo/refresh does not try to reinvent the wheel! Instead, it uses the already great wheels developed by the Go community and puts them all together in the best way possible. Without these giants, this project would not be possible. Please make sure to check them out and thank them for all of their hard work.

Thank you to the following **GIANTS**:

* [github.com/cpuguy83/go-md2man/v2](https://godoc.org/github.com/cpuguy83/go-md2man/v2)
* [github.com/fatih/color](https://godoc.org/github.com/fatih/color)
* [github.com/fsnotify/fsnotify](https://godoc.org/github.com/fsnotify/fsnotify)
* [github.com/inconshreveable/mousetrap](https://godoc.org/github.com/inconshreveable/mousetrap)
* [github.com/mattn/go-colorable](https://godoc.org/github.com/mattn/go-colorable)
* [github.com/mattn/go-isatty](https://godoc.org/github.com/mattn/go-isatty)
* [github.com/mitchellh/go-homedir](https://godoc.org/github.com/mitchellh/go-homedir)
* [github.com/russross/blackfriday/v2](https://godoc.org/github.com/russross/blackfriday/v2)
* [github.com/spf13/cobra](https://godoc.org/github.com/spf13/cobra)
* [github.com/spf13/pflag](https://godoc.org/github.com/spf13/pflag)
* [golang.org/x/sys](https://godoc.org/golang.org/x/sys)
* [gopkg.in/check.v1](https://godoc.org/gopkg.in/check.v1)
* [gopkg.in/yaml.v2](https://godoc.org/gopkg.in/yaml.v2)
