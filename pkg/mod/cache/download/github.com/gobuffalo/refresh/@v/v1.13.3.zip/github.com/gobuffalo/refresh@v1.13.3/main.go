package main

import "github.com/gobuffalo/refresh/cmd"

func main() {
	cmd.Execute()
}
