# github.com/gobuffalo/github_flavored_markdown Stands on the Shoulders of Giants

github.com/gobuffalo/github_flavored_markdown does not try to reinvent the wheel! Instead, it uses the already great wheels developed by the Go community and puts them all together in the best way possible. Without these giants, this project would not be possible. Please make sure to check them out and thank them for all of their hard work.

Thank you to the following **GIANTS**:


* [github.com/kr/pretty](https://godoc.org/github.com/kr/pretty)

* [github.com/microcosm-cc/bluemonday](https://godoc.org/github.com/microcosm-cc/bluemonday)

* [github.com/sergi/go-diff](https://godoc.org/github.com/sergi/go-diff)

* [github.com/sourcegraph/annotate](https://godoc.org/github.com/sourcegraph/annotate)

* [github.com/sourcegraph/syntaxhighlight](https://godoc.org/github.com/sourcegraph/syntaxhighlight)

* [github.com/stretchr/testify](https://godoc.org/github.com/stretchr/testify)

* [golang.org/x/net](https://godoc.org/golang.org/x/net)
