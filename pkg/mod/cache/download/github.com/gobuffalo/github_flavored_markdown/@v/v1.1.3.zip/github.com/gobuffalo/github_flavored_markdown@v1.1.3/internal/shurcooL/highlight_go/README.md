highlight_go
============

[![Build Status](https://travis-ci.org/shurcooL/highlight_go.svg?branch=master)](https://travis-ci.org/shurcooL/highlight_go) [![GoDoc](https://godoc.org/github.com/shurcooL/highlight_go?status.svg)](https://godoc.org/github.com/shurcooL/highlight_go)

Package highlight_go provides a syntax highlighter for Go, using go/scanner.

Installation
------------

```bash
go get -u github.com/shurcooL/highlight_go
```

License
-------

-	[MIT License](https://opensource.org/licenses/mit-license.php)
