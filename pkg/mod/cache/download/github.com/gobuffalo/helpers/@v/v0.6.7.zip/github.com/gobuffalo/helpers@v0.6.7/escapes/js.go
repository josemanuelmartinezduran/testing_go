package escapes

import "html/template"

// JSEscape will escape a string for Javascript
var JSEscape = template.JSEscapeString
