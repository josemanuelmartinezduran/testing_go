# github.com/gobuffalo/x Stands on the Shoulders of Giants

github.com/gobuffalo/x does not try to reinvent the wheel! Instead, it uses the already great wheels developed by the Go community and puts them all together in the best way possible. Without these giants, this project would not be possible. Please make sure to check them out and thank them for all of their hard work.

Thank you to the following **GIANTS**:


* [github.com/gobuffalo/buffalo](https://godoc.org/github.com/gobuffalo/buffalo)

* [github.com/gorilla/sessions](https://godoc.org/github.com/gorilla/sessions)

* [github.com/jackc/pgx](https://godoc.org/github.com/jackc/pgx)

* [github.com/markbates/going](https://godoc.org/github.com/markbates/going)

* [github.com/spf13/afero](https://godoc.org/github.com/spf13/afero)

* [github.com/stretchr/testify](https://godoc.org/github.com/stretchr/testify)
