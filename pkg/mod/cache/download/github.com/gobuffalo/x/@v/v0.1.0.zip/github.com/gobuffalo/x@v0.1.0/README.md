# github.com/gobuffalo/x [![Build Status](https://travis-ci.org/gobuffalo/x.svg?branch=master)](https://travis-ci.org/gobuffalo/x)

This collection of packages is meant to be a "testing" ground for Buffalo packages that may *or may not* get included in future versions of Buffalo.

Feedback on these packages, their use, etc... is greatly appreciated.

## Compatibility

These packages *should* always work with the "latest" version of Buffalo, i.e. the `master` branch. Exceptions will be noted.
