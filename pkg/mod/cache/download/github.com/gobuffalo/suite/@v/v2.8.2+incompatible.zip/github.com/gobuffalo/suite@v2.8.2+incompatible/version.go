package suite

const Version = "v2.8.2"
