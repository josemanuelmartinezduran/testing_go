package suite

// Version of Suite
const Version = "v4.0.4"
