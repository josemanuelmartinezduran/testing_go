# lsp

internal/lsp provides much of the Language Server Protocol (lsp) implementation
for gopls.

Documentation for users and contributors can be found in the
[`gopls/doc`](../../gopls/doc) directory.
